#!/bin/bash
java -jar orbit.jar $@
